CREATE TABLE IF NOT EXISTS TB_ProductModel (
    ProductModelID INT NOT NULL,
    ProductModelName VARCHAR(50) NOT NULL,
    CONSTRAINT PK_ProductModel PRIMARY KEY (ProductModelID)
);